## How to use Anveshak UPI Pay
* To send a specific amount to a particular UPI id, use `https://deimos2683.github.io/upi?<upi_id>&<amt>`
* To send without any specific amount, `https://deimos2683.github.io/upi/index.html?<upi_id>`
